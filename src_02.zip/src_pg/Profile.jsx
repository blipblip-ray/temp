import { useState } from 'react'
import { useAuth } from '../auth.jsx'
import { api } from '../api.js'
import { MASCOTS, COUNTRIES } from '../data.js'
import Avatar from '../Avatar.jsx'

export default function Profile() {
  const { user, refreshUser } = useAuth()
  const [mascot, setMascot] = useState(user?.mascot || '')
  const [country, setCountry] = useState(user?.supported_country || '')
  const [msg, setMsg] = useState(null)
  const [busy, setBusy] = useState(false)

  async function save() {
    setBusy(true); setMsg(null)
    try {
      await api('/api/me', { method: 'PATCH', body: { mascot: mascot || null, supported_country: country } })
      await refreshUser()
      setMsg({ kind: 'ok', text: 'Saved — your avatar is updated across the pool.' })
    } catch (e) { setMsg({ kind: 'err', text: e.message }) }
    finally { setBusy(false) }
  }

  const preview = { display_name: user?.display_name, mascot, supported_country: country }

  return (
    <div className="container">
      <h1 className="page-title">Profile</h1>
      <p className="page-sub">Pick your mascot and the country you support — together they become your avatar.</p>

      <div className="grid2">
        <div className="panel">
          <p className="section-label">Choose your mascot</p>
          <div className="mascot-pick">
            {MASCOTS.map(m => (
              <button key={m.id} type="button"
                className={'mascot-opt' + (mascot === m.id ? ' sel' : '')}
                onClick={() => setMascot(mascot === m.id ? '' : m.id)}>
                <img src={m.img} alt="" />
                <span>{m.name}</span>
              </button>
            ))}
          </div>

          <div className="field" style={{ marginTop: 18 }}>
            <label className="muted" style={{ fontSize: 13 }}>Country you support</label>
            <select className="stake-input" value={country} onChange={e => setCountry(e.target.value)}>
              <option value="">Select a country…</option>
              {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <button className="btn btn-primary" style={{ marginTop: 16 }} disabled={busy} onClick={save}>
            {busy ? 'Saving…' : 'Save profile'}
          </button>
          {msg && <div className={'msg ' + (msg.kind === 'ok' ? 'ok' : 'err')}>{msg.text}</div>}
        </div>

        <div className="panel" style={{ textAlign: 'center' }}>
          <p className="section-label">Preview</p>
          <div style={{ display: 'grid', placeItems: 'center', padding: '14px 0' }}>
            <Avatar user={preview} size={130} />
            <div style={{ marginTop: 14, fontWeight: 700, fontSize: 16 }}>{user?.display_name}</div>
            <div className="muted" style={{ fontSize: 13 }}>{country ? `Supporting ${country}` : 'No country picked yet'}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
