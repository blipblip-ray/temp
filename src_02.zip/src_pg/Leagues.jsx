import { useEffect, useState } from 'react'
import { getLeagues, createLeague, joinLeague, getLeagueBoard } from '../api.js'
import Avatar from '../Avatar.jsx'

export default function Leagues() {
  const [leagues, setLeagues] = useState(null)
  const [selected, setSelected] = useState(null)
  const [board, setBoard] = useState(null)
  const [err, setErr] = useState('')

  const [newName, setNewName] = useState('')
  const [joinCode, setJoinCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)
  const [copied, setCopied] = useState('')

  async function loadLeagues(pickId) {
    const rows = await getLeagues()
    setLeagues(rows)
    const pick = pickId ? rows.find(l => l.id === pickId) : (selected || rows[0])
    if (pick) openLeague(pick)
  }

  useEffect(() => {
    getLeagues()
      .then(rows => {
        setLeagues(rows)
        if (rows[0]) openLeague(rows[0])
      })
      .catch(e => setErr(e.message))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function openLeague(lg) {
    setSelected(lg)
    setBoard(null)
    getLeagueBoard(lg.id).then(setBoard).catch(e => setErr(e.message))
  }

  async function onCreate(e) {
    e.preventDefault()
    if (!newName.trim()) return
    setBusy(true); setMsg(null)
    try {
      const lg = await createLeague(newName.trim())
      setNewName('')
      setMsg({ kind: 'ok', text: `League "${lg.name}" created. Share code ${lg.code} with your friends.` })
      await loadLeagues(lg.id)
    } catch (e) { setMsg({ kind: 'err', text: e.message }) }
    finally { setBusy(false) }
  }

  async function onJoin(e) {
    e.preventDefault()
    if (!joinCode.trim()) return
    setBusy(true); setMsg(null)
    try {
      const lg = await joinLeague(joinCode.trim())
      setJoinCode('')
      setMsg({ kind: 'ok', text: `Joined "${lg.name}".` })
      await loadLeagues(lg.id)
    } catch (e) { setMsg({ kind: 'err', text: e.message }) }
    finally { setBusy(false) }
  }

  function copyCode(code) {
    navigator.clipboard?.writeText(code).then(() => {
      setCopied(code)
      setTimeout(() => setCopied(''), 1500)
    }).catch(() => {})
  }

  if (err) return <div className="container"><div className="msg err">{err}</div></div>
  if (!leagues) return <div className="container"><div className="loading">Loading leagues…</div></div>

  const standings = board?.standings || []
  const settle = board?.settle
  const loserName = settle?.loser?.display_name

  return (
    <div className="container">
      <h1 className="page-title">Leagues</h1>
      <p className="page-sub">Everyone competes in the World leaderboard. Create a private league and share its code so your friends can join.</p>

      <div className="grid2">
        <form className="panel" onSubmit={onCreate}>
          <p className="section-label">Create a league</p>
          <div className="field">
            <label className="muted" style={{ fontSize: 13 }}>League name</label>
            <input className="stake-input" value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. The Office Pool" />
          </div>
          <button className="btn btn-primary" style={{ marginTop: 12 }} disabled={busy}>Create league</button>
        </form>

        <form className="panel" onSubmit={onJoin}>
          <p className="section-label">Join with a code</p>
          <div className="field">
            <label className="muted" style={{ fontSize: 13 }}>League code</label>
            <input className="stake-input" value={joinCode} onChange={e => setJoinCode(e.target.value.toUpperCase())} placeholder="e.g. GOAL2026" />
          </div>
          <button className="btn btn-primary" style={{ marginTop: 12 }} disabled={busy}>Join league</button>
        </form>
      </div>
      {msg && <div className={'msg ' + (msg.kind === 'ok' ? 'ok' : 'err')} style={{ marginTop: 12 }}>{msg.text}</div>}

      <p className="section-label" style={{ marginTop: 26 }}>Your leagues</p>
      <div className="league-chips">
        {leagues.map(l => (
          <button key={l.id}
            className={'league-chip' + (selected?.id === l.id ? ' active' : '')}
            onClick={() => openLeague(l)}>
            {l.is_world ? 'World' : l.name}
            <span className="muted2" style={{ marginLeft: 8, fontSize: 12 }}>
              {l.member_count} {l.member_count === 1 ? 'player' : 'players'}
              {l.my_rank ? ` · #${l.my_rank}` : ''}
            </span>
          </button>
        ))}
      </div>

      {selected && (
        <div style={{ marginTop: 18 }}>
          <div className="team" style={{ justifyContent: 'space-between' }}>
            <h2 style={{ margin: 0 }}>{selected.is_world ? 'World' : selected.name}</h2>
            {!selected.is_world && (
              <button className="btn" onClick={() => copyCode(selected.code)}>
                {copied === selected.code ? 'Copied!' : `Code: ${selected.code}`}
              </button>
            )}
          </div>

          {!board ? (
            <div className="loading">Loading standings…</div>
          ) : (
            <>
              <div className="table-wrap" style={{ marginTop: 12 }}>
                <table className="matches">
                  <thead><tr><th>#</th><th>Player</th><th>Supports</th><th>Net</th><th>W/L</th><th>Pending</th><th>ROI</th></tr></thead>
                  <tbody>
                    {standings.map(r => (
                      <tr key={r.user_id}>
                        <td><b>{r.rank}</b></td>
                        <td>
                          <div className="team">
                            <Avatar user={r} size={30} />
                            {r.display_name}
                            {loserName && r.display_name === loserName && standings.length > 1 && <span className="loser-tag">dare</span>}
                          </div>
                        </td>
                        <td className="muted" style={{ fontSize: 13 }}>{r.supported_country || '—'}</td>
                        <td><b className={'net ' + (r.net >= 0 ? 'pos' : 'neg')}>{r.net >= 0 ? '+' : ''}{Math.round(r.net)} ₹</b></td>
                        <td className="muted">{r.wins} / {r.losses}</td>
                        <td className="muted">{r.pending}</td>
                        <td className="muted">{r.roi}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {settle && settle.transfers && settle.transfers.length > 0 && (
                <div className="panel" style={{ marginTop: 18 }}>
                  <p className="section-label">Settle up (so far)</p>
                  {settle.transfers.map((t, i) => (
                    <div key={i} className="slip-line">
                      <span><b>{t.from}</b> pays <b>{t.to}</b></span>
                      <b>{t.amount} ₹</b>
                    </div>
                  ))}
                  <p className="muted2" style={{ fontSize: 12, marginTop: 8 }}>Final settlement is calculated when every match is done. Last place does the dare.</p>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}
