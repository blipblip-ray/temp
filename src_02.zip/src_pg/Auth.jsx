import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../auth.jsx'
import { login as apiLogin, register as apiRegister } from '../api.js'
import Brand from '../Brand.jsx'
import { MASCOTS, COUNTRIES } from '../data.js'

export default function Auth() {
  const { login } = useAuth()
  const nav = useNavigate()
  const [mode, setMode] = useState('login')
  const [f, setF] = useState({ username: '', password: '', display_name: '', supported_country: '', mascot: '' })
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  async function submit(e) {
    e.preventDefault()
    setErr(''); setBusy(true)
    try {
      const res = mode === 'login'
        ? await apiLogin(f.username, f.password)
        : await apiRegister(f)
      login(res.access_token)
      nav('/')
    } catch (e) {
      setErr(e.message || 'Something went wrong')
    } finally { setBusy(false) }
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <div style={{ marginBottom: 18 }}><Brand size="hero" /></div>
        <h1>{mode === 'login' ? 'Welcome back' : 'Join the pool'}</h1>
        <p className="muted" style={{ margin: 0, fontSize: 14 }}>
          {mode === 'login' ? 'Log in to place your bets.' : 'Create your account and join the World leaderboard.'}
        </p>

        <div className="field">
          <label>Username</label>
          <input value={f.username} onChange={set('username')} autoComplete="username" required />
        </div>
        <div className="field">
          <label>Password</label>
          <input type="password" value={f.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required />
        </div>

        {mode === 'register' && (
          <>
            <div className="field">
              <label>Display name</label>
              <input value={f.display_name} onChange={set('display_name')} required />
            </div>
            <div className="field">
              <label>Country you support</label>
              <select value={f.supported_country} onChange={set('supported_country')}>
                <option value="">Select a country…</option>
                {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Your mascot</label>
              <div className="mascot-pick">
                {MASCOTS.map(m => (
                  <button key={m.id} type="button"
                    className={'mascot-opt' + (f.mascot === m.id ? ' sel' : '')}
                    onClick={() => setF({ ...f, mascot: f.mascot === m.id ? '' : m.id })}>
                    <img src={m.img} alt="" /><span>{m.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {err && <div className="msg err">{err}</div>}
        <button className="btn btn-primary" style={{ width: '100%', marginTop: 14 }} disabled={busy}>
          {busy ? 'Please wait…' : (mode === 'login' ? 'Log in' : 'Create account')}
        </button>

        <div className="switch">
          {mode === 'login' ? "No account yet? " : 'Already have one? '}
          <button type="button" onClick={() => { setErr(''); setMode(mode === 'login' ? 'register' : 'login') }}>
            {mode === 'login' ? 'Register' : 'Log in'}
          </button>
        </div>
      </form>
    </div>
  )
}
