import { useEffect, useState } from 'react'
import { getLeaderboard } from '../api.js'
import Avatar from '../Avatar.jsx'

export default function Leaderboard() {
  const [rows, setRows] = useState(null)
  const [err, setErr] = useState('')

  useEffect(() => {
    getLeaderboard().then(setRows).catch(e => setErr(e.message))
  }, [])

  if (err) return <div className="container"><div className="msg err">{err}</div></div>
  if (!rows) return <div className="container"><div className="loading">Loading standings…</div></div>

  const top = rows.slice(0, 3)
  const order = [1, 0, 2] // silver, gold, bronze visual order

  return (
    <div className="container">
      <h1 className="page-title">World leaderboard</h1>
      <p className="page-sub">Every player, ranked by net profit. Head to Leagues to compete privately with your friends.</p>

      {top.length >= 3 && (
        <div className="podium">
          {order.map(idx => {
            const r = top[idx]
            if (!r) return <div key={idx} />
            const g = idx === 0 ? 'g1' : idx === 1 ? 'g2' : 'g3'
            return (
              <div key={r.user_id} className={'pod ' + g}>
                <div className="rk muted">#{r.rank}</div>
                <div style={{ display: 'grid', placeItems: 'center', margin: '6px 0 8px' }}><Avatar user={r} size={50} /></div>
                <div className="nm">{r.display_name}</div>
                <div className={'net ' + (r.net >= 0 ? 'pos' : 'neg')}>{r.net >= 0 ? '+' : ''}{Math.round(r.net)} ₹</div>
                <div className="muted2" style={{ fontSize: 12 }}>{r.wins}W · {r.losses}L</div>
              </div>
            )
          })}
        </div>
      )}

      <div className="table-wrap">
        <table className="matches">
          <thead><tr><th>#</th><th>Player</th><th>Supports</th><th>Net</th><th>W/L</th><th>Pending</th><th>ROI</th></tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.user_id}>
                <td><b>{r.rank}</b></td>
                <td>
                  <div className="team">
                    <Avatar user={r} size={30} />
                    {r.display_name}
                  </div>
                </td>
                <td className="muted" style={{ fontSize: 13 }}>{r.supported_country || '—'}</td>
                <td><b className={'net ' + (r.net >= 0 ? 'pos' : 'neg')}>{r.net >= 0 ? '+' : ''}{Math.round(r.net)} ₹</b></td>
                <td className="muted">{r.wins} / {r.losses}</td>
                <td className="muted">{r.pending}</td>
                <td className="muted">{r.roi}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
