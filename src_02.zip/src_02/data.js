// Static, known tournament data (the schedule itself comes from the API).

// 16 host stadiums with real coordinates, used for the map.
export const STADIUMS = [
  { city: 'Vancouver',     venue: 'BC Place',                country: 'CA', cap: 54000, lat: 49.28, lon: -123.11 },
  { city: 'Seattle',       venue: 'Lumen Field',             country: 'US', cap: 69000, lat: 47.60, lon: -122.33 },
  { city: 'San Francisco', venue: "Levi's Stadium",          country: 'US', cap: 71000, lat: 37.40, lon: -121.97 },
  { city: 'Los Angeles',   venue: 'SoFi Stadium',            country: 'US', cap: 70000, lat: 33.95, lon: -118.34 },
  { city: 'Kansas City',   venue: 'Arrowhead Stadium',       country: 'US', cap: 73000, lat: 39.05, lon: -94.48 },
  { city: 'Dallas',        venue: 'AT&T Stadium',            country: 'US', cap: 94000, lat: 32.75, lon: -97.09 },
  { city: 'Houston',       venue: 'NRG Stadium',             country: 'US', cap: 72000, lat: 29.68, lon: -95.41 },
  { city: 'Atlanta',       venue: 'Mercedes-Benz Stadium',   country: 'US', cap: 75000, lat: 33.75, lon: -84.40 },
  { city: 'Miami',         venue: 'Hard Rock Stadium',       country: 'US', cap: 65000, lat: 25.96, lon: -80.24 },
  { city: 'New York / NJ', venue: 'MetLife Stadium',         country: 'US', cap: 82500, lat: 40.81, lon: -74.07 },
  { city: 'Boston',        venue: 'Gillette Stadium',        country: 'US', cap: 65000, lat: 42.09, lon: -71.26 },
  { city: 'Philadelphia',  venue: 'Lincoln Financial Field', country: 'US', cap: 69000, lat: 39.90, lon: -75.17 },
  { city: 'Toronto',       venue: 'BMO Field',               country: 'CA', cap: 45000, lat: 43.63, lon: -79.42 },
  { city: 'Monterrey',     venue: 'Estadio BBVA',            country: 'MX', cap: 53500, lat: 25.67, lon: -100.24 },
  { city: 'Guadalajara',   venue: 'Estadio Akron',           country: 'MX', cap: 48000, lat: 20.68, lon: -103.46 },
  { city: 'Mexico City',   venue: 'Estadio Azteca',          country: 'MX', cap: 83000, lat: 19.30, lon: -99.15 },
]

export const COUNTRY_COLORS = { US: '#ff6b5e', MX: '#ffb347', CA: '#ff4d8d' }
export const COUNTRY_NAMES = { US: 'United States', MX: 'Mexico', CA: 'Canada' }

// Find the stadium that best matches an API fixture's venue/city string.
export function matchStadium(venue, city) {
  const v = (venue || '').toLowerCase()
  const c = (city || '').toLowerCase()
  return (
    STADIUMS.find(s => v && (v.includes(s.venue.toLowerCase()) || s.venue.toLowerCase().includes(v))) ||
    STADIUMS.find(s => c && c.includes(s.city.split(' ')[0].toLowerCase())) ||
    null
  )
}

// The 12 groups (with ISO codes for flag images).
export const GROUPS = [
  { name: 'A', teams: [['Mexico','mx'],['South Africa','za'],['South Korea','kr'],['Czechia','cz']] },
  { name: 'B', teams: [['Canada','ca'],['Qatar','qa'],['Switzerland','ch'],['Bosnia-Herzegovina','ba']] },
  { name: 'C', teams: [['Brazil','br'],['Morocco','ma'],['Haiti','ht'],['Scotland','gb-sct']] },
  { name: 'D', teams: [['United States','us'],['Paraguay','py'],['Australia','au'],['Türkiye','tr']] },
  { name: 'E', teams: [['Germany','de'],['Curaçao','cw'],['Ivory Coast','ci'],['Ecuador','ec']] },
  { name: 'F', teams: [['Netherlands','nl'],['Japan','jp'],['Tunisia','tn'],['Sweden','se']] },
  { name: 'G', teams: [['Belgium','be'],['Egypt','eg'],['Iran','ir'],['New Zealand','nz']] },
  { name: 'H', teams: [['Spain','es'],['Cape Verde','cv'],['Saudi Arabia','sa'],['Uruguay','uy']] },
  { name: 'I', teams: [['France','fr'],['Iraq','iq'],['Senegal','sn'],['Norway','no']] },
  { name: 'J', teams: [['Argentina','ar'],['Algeria','dz'],['Austria','at'],['Jordan','jo']] },
  { name: 'K', teams: [['DR Congo','cd'],['Portugal','pt'],['Uzbekistan','uz'],['Colombia','co']] },
  { name: 'L', teams: [['England','gb-eng'],['Croatia','hr'],['Ghana','gh'],['Panama','pa']] },
]

export const flagUrl = (iso) => `https://flagcdn.com/w40/${iso}.png`

// Alphabetical list of the 48 participating teams (for the "country you support" dropdown).
export const COUNTRIES = GROUPS
  .flatMap(g => g.teams.map(([name]) => name))
  .sort((a, b) => a.localeCompare(b))

// The three official mascots (your uploaded images live in /public/mascots).
export const MASCOTS = [
  { id: 'eagle',  name: 'Clutch', img: '/mascots/eagle.png' },
  { id: 'jaguar', name: 'Zayu',   img: '/mascots/jaguar.png' },
  { id: 'moose',  name: 'Maple',  img: '/mascots/moose.png' },
]
export const mascotImg = (id) => (MASCOTS.find(m => m.id === id) || {}).img || null

// country name -> ISO2 for flag images (built from the group data + aliases)
const NAME_TO_ISO = (() => {
  const map = {}
  for (const g of GROUPS) for (const [name, iso] of g.teams) map[name.toLowerCase()] = iso
  const alias = {
    'usa': 'us', 'united states': 'us', 'u.s.a.': 'us', 'america': 'us',
    'korea': 'kr', 'south korea': 'kr', 'türkiye': 'tr', 'turkiye': 'tr', 'turkey': 'tr',
    'ivory coast': 'ci', "cote d'ivoire": 'ci', 'czech republic': 'cz', 'czechia': 'cz',
    'bosnia': 'ba', 'uae': 'ae', 'holland': 'nl', 'england': 'gb-eng', 'scotland': 'gb-sct', 'wales': 'gb-wls',
  }
  return { ...map, ...alias }
})()
export const isoForCountry = (name) => name ? (NAME_TO_ISO[name.trim().toLowerCase()] || null) : null

// Stadium stills shown on the map pins. They live in backend/media/stadium_photos
// and are named exactly like your stadium video clips (e.g. "Atalanta Stadium.png"),
// served at /media/stadium_photos/<clip name>.<ext>. The map tries .png then .jpg,
// so either format works. Missing files degrade to a plain coloured pin.
const STADIUM_CLIPS = {
  'BC Place': 'BC Place Vancouver',
  'Lumen Field': 'Seattle Stadium',
  "Levi's Stadium": 'San Francisco Bay Stadium',
  'SoFi Stadium': 'Los Angeles Stadium',
  'Arrowhead Stadium': 'Kansas CIty Stadium',
  'AT&T Stadium': 'Dallas Stadium',
  'NRG Stadium': 'Houston Stadium',
  'Mercedes-Benz Stadium': 'Atalanta Stadium',
  'Hard Rock Stadium': 'Miami Stadium',
  'MetLife Stadium': 'New York Stadium',
  'Gillette Stadium': 'Boston Stadium',
  'Lincoln Financial Field': 'Philadelphia Stadium',
  'BMO Field': 'Toronto Stadium',
  'Estadio BBVA': 'Estadio Monterrey',
  'Estadio Akron': 'Estadio Akron',
  'Estadio Azteca': 'Estadio Azteca',
}
export const stadiumClip = (s) => STADIUM_CLIPS[s.venue] || s.city
export const stadiumPhoto = (s) => `/media/stadium_photos/${encodeURIComponent(stadiumClip(s))}.png`
