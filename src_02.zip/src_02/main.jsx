import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './auth.jsx'
import Layout from './Layout.jsx'
import Auth from './pages/Auth.jsx'
import Fixtures from './pages/Fixtures.jsx'
import FixtureDetail from './pages/FixtureDetail.jsx'
import MyBets from './pages/MyBets.jsx'
import Leaderboard from './pages/Leaderboard.jsx'
import Leagues from './pages/Leagues.jsx'
import Groups from './pages/Groups.jsx'
import Stadiums from './pages/Stadiums.jsx'
import Profile from './pages/Profile.jsx'
import Background from './Background.jsx'
import './styles.css'

function Protected({ children }) {
  const { token, ready } = useAuth()
  if (!ready) return <div className="loading">Loading…</div>
  if (!token) return <Navigate to="/login" replace />
  return children
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <Background />
      <HashRouter>
        <Routes>
          <Route path="/login" element={<Auth />} />
          <Route element={<Protected><Layout /></Protected>}>
            <Route path="/" element={<Fixtures />} />
            <Route path="/fixtures/:id" element={<FixtureDetail />} />
            <Route path="/my-bets" element={<MyBets />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/leagues" element={<Leagues />} />
            <Route path="/groups" element={<Groups />} />
            <Route path="/stadiums" element={<Stadiums />} />
            <Route path="/profile" element={<Profile />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </HashRouter>
    </AuthProvider>
  </React.StrictMode>
)
