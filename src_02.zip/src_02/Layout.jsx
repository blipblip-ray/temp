import { useEffect, useState } from 'react'
import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom'
import { useAuth } from './auth.jsx'
import { getLeaderboard } from './api.js'
import Brand from './Brand.jsx'
import Avatar from './Avatar.jsx'

function initials(name) {
  return (name || '?').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
}

export default function Layout() {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [net, setNet] = useState(null)

  useEffect(() => {
    let on = true
    getLeaderboard()
      .then(rows => { if (!on) return; const me = rows.find(r => r.user_id === user?.id); setNet(me ? me.net : 0) })
      .catch(() => {})
    return () => { on = false }
  }, [user])

  return (
    <div>
      <nav className="nav">
        <Brand />
        <div className="nav-links">
          <NavLink to="/" end>Fixtures</NavLink>
          <NavLink to="/my-bets">My Bets</NavLink>
          <NavLink to="/leaderboard">Leaderboard</NavLink>
          <NavLink to="/leagues">Leagues</NavLink>
          <NavLink to="/groups">Groups</NavLink>
          <NavLink to="/stadiums">Stadiums</NavLink>
        </div>
        <div className="nav-user">
          {net !== null && (
            <span className={'balance ' + (net >= 0 ? 'pos' : 'neg')}>
              {net >= 0 ? '+' : ''}{Math.round(net)} ₹
            </span>
          )}
          <Link to="/profile" title="Edit profile"><Avatar user={user} size={36} /></Link>
          <button className="btn" onClick={() => { logout(); nav('/login') }}>Logout</button>
        </div>
      </nav>
      <Outlet />
    </div>
  )
}
