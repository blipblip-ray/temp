let TOKEN = ''
export function setToken(t) { TOKEN = t || '' }

async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {}
  let payload
  if (form) {
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    payload = new URLSearchParams(form).toString()
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json'
    payload = JSON.stringify(body)
  }
  if (TOKEN) headers['Authorization'] = `Bearer ${TOKEN}`

  const res = await fetch(path, { method, headers, body: payload })
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`
    try { const j = await res.json(); if (j && j.detail) detail = typeof j.detail === 'string' ? j.detail : JSON.stringify(j.detail) } catch (e) {}
    throw new Error(detail)
  }
  if (res.status === 204) return null
  return res.json()
}

export { api }
export const login = (username, password) => api('/api/auth/login', { method: 'POST', form: { username, password } })
export const register = (data) => api('/api/auth/register', { method: 'POST', body: data })
export const getMe = () => api('/api/me')
export const getFixtures = (scope) => api(`/api/fixtures?scope=${encodeURIComponent(scope)}`)
export const getFixture = (id) => api(`/api/fixtures/${id}`)
export const getFixtureVideo = (id) => api(`/api/fixtures/${id}/video`)
export const placeBet = (data) => api('/api/bets', { method: 'POST', body: data })
export const getMyBets = () => api('/api/bets/me')
export const getLeaderboard = () => api('/api/leaderboard')
export const getSettleUp = () => api('/api/settle-up')
export const getLeagues = () => api('/api/leagues')
export const createLeague = (name) => api('/api/leagues', { method: 'POST', body: { name } })
export const joinLeague = (code) => api('/api/leagues/join', { method: 'POST', body: { code } })
export const getLeagueBoard = (id) => api(`/api/leagues/${id}/leaderboard`)
