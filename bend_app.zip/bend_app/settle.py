"""
Settle bets on regulation (90-minute / full-time) results, build the leaderboard,
and compute the end-of-tournament settle-up.

Convention: all markets settle on the 90-minute result. A knockout match drawn after
90 minutes settles as a DRAW even if it's later decided in extra time or on penalties —
this matches the standard "Full Time Result" sportsbook market.
"""
from datetime import datetime

from sqlmodel import Session, select

from .models import Bet, Fixture, User

FINISHED = {"FT", "AET", "PEN"}


def settle_fixture(session: Session, fx: Fixture) -> int:
    """Grade all pending bets on a finished fixture. Idempotent. Returns bets settled."""
    if fx.settled or fx.status not in FINISHED:
        return 0
    if fx.home_score is None or fx.away_score is None:
        return 0

    h, a = fx.home_score, fx.away_score
    result = "HOME" if h > a else ("AWAY" if a > h else "DRAW")
    exact = f"{h}-{a}"

    bets = session.exec(
        select(Bet).where(Bet.fixture_id == fx.id, Bet.status == "pending")
    ).all()

    n = 0
    for b in bets:
        won = (
            (b.market == "1X2" and b.selection == result)
            or (b.market == "SCORELINE" and b.selection == exact)
        )
        b.status = "won" if won else "lost"
        b.profit = round(b.payout - b.stake, 2) if won else float(-b.stake)
        b.settled_at = datetime.utcnow()
        session.add(b)
        n += 1

    fx.settled = True
    session.add(fx)
    session.commit()
    return n


def leaderboard(session: Session, user_ids=None) -> list[dict]:
    """Standings ranked by net profit. If user_ids is given, only those users
    are ranked (used for a specific league); otherwise everyone (the World)."""
    query = select(User)
    if user_ids is not None:
        ids = list(user_ids)
        if not ids:
            return []
        query = query.where(User.id.in_(ids))
    users = session.exec(query).all()
    rows = []
    for u in users:
        bets = session.exec(select(Bet).where(Bet.user_id == u.id)).all()
        graded = [b for b in bets if b.status in ("won", "lost")]
        net = round(sum(b.profit or 0.0 for b in graded), 2)
        staked = sum(b.stake for b in graded)
        wins = sum(1 for b in graded if b.status == "won")
        losses = sum(1 for b in graded if b.status == "lost")
        pending = sum(1 for b in bets if b.status == "pending")
        rows.append({
            "user_id": u.id,
            "display_name": u.display_name,
            "supported_country": u.supported_country,
            "avatar_path": u.avatar_path,
            "mascot": u.mascot,
            "net": net,
            "staked": staked,
            "wins": wins,
            "losses": losses,
            "pending": pending,
            "roi": round(net / staked * 100, 1) if staked else 0.0,
        })
    rows.sort(key=lambda r: r["net"], reverse=True)
    for i, r in enumerate(rows, start=1):
        r["rank"] = i
    return rows


def settle_up(session: Session, user_ids=None) -> dict:
    """Minimal set of payments to square everyone up, plus who has to do the dare.
    Scoped to user_ids when given (a league); otherwise everyone."""
    board = leaderboard(session, user_ids=user_ids)
    if not board:
        return {"transfers": [], "loser": None, "standings": []}

    debtors = sorted([[r["display_name"], round(r["net"])] for r in board if round(r["net"]) < 0],
                     key=lambda x: x[1])           # most negative first
    creditors = sorted([[r["display_name"], round(r["net"])] for r in board if round(r["net"]) > 0],
                       key=lambda x: -x[1])         # most positive first

    transfers = []
    i = j = 0
    while i < len(debtors) and j < len(creditors):
        pay = min(-debtors[i][1], creditors[j][1])
        if pay > 0:
            transfers.append({
                "from": debtors[i][0],
                "to": creditors[j][0],
                "amount": pay,
            })
        debtors[i][1] += pay
        creditors[j][1] -= pay
        if debtors[i][1] == 0:
            i += 1
        if creditors[j][1] == 0:
            j += 1

    loser = board[-1]  # lowest net
    return {
        "transfers": transfers,
        "loser": {"display_name": loser["display_name"], "net": loser["net"]},
        "standings": board,
    }


def apply_manual_result(session: Session, fx: Fixture, home_score: int,
                        away_score: int, force: bool = False) -> dict:
    """Admin sets a final score by hand. Settles the fixture. With force=True it can
    re-grade an already-settled fixture (to correct a wrong/auto result)."""
    if fx.settled and not force:
        return {"settled": False, "reason": "Already settled. Pass force=true to override."}

    if fx.settled and force:
        graded = session.exec(
            select(Bet).where(Bet.fixture_id == fx.id, Bet.status.in_(("won", "lost")))
        ).all()
        for b in graded:
            b.status = "pending"
            b.profit = None
            b.settled_at = None
            session.add(b)
        fx.settled = False

    fx.home_score = home_score
    fx.away_score = away_score
    fx.status = "FT"
    session.add(fx)
    session.commit()
    n = settle_fixture(session, fx)
    return {"settled": True, "bets_graded": n,
            "result": f"{fx.home_name} {home_score}-{away_score} {fx.away_name}"}
