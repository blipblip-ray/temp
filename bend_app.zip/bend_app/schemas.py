from typing import Optional
from pydantic import BaseModel


class RegisterIn(BaseModel):
    username: str
    password: str
    display_name: str
    supported_country: Optional[str] = None
    mascot: Optional[str] = None


class LeagueCreateIn(BaseModel):
    name: str


class LeagueJoinIn(BaseModel):
    code: str


class ProfileIn(BaseModel):
    mascot: Optional[str] = None
    supported_country: Optional[str] = None


class LoginIn(BaseModel):
    username: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class BetIn(BaseModel):
    fixture_id: int
    market: str       # "1X2" or "SCORELINE"
    selection: str    # "HOME"/"DRAW"/"AWAY" or "2-1"
    stake: int


class EloIn(BaseModel):
    team_id: int
    elo: float


class ResultIn(BaseModel):
    fixture_id: int
    home_score: int
    away_score: int
    force: bool = False
