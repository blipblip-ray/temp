from pathlib import Path
from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy import text

DB_PATH = Path(__file__).resolve().parent.parent / "app.db"
engine = create_engine(
    f"sqlite:///{DB_PATH}",
    connect_args={"check_same_thread": False},
)


WORLD_CODE = "WORLD"
GOAL2026_CODE = "GOAL2026"


def init_db():
    # Import models so SQLModel registers the tables before create_all.
    from . import models  # noqa: F401
    SQLModel.metadata.create_all(engine)
    _ensure_columns()
    seed_leagues()


def seed_leagues():
    """Idempotent, NON-destructive startup migration. It never deletes or modifies
    existing users/bets; it only creates the World + GOAL2026 leagues and adds
    memberships.

    - World = everyone, always: every existing user is ensured into World on each
      startup (new signups are also added to World by the register endpoint).
    - GOAL2026 = the original friends' league. We backfill the users that already
      exist ONLY when this league is first created (on a pre-leagues database they
      all signed up with the GOAL2026 code). On later restarts we do NOT auto-add
      anyone to GOAL2026, so future World-only signups don't get pulled into it."""
    from sqlmodel import select
    from .models import League, LeagueMember, User

    with Session(engine) as session:
        admin = session.exec(select(User).where(User.is_admin == True)).first()  # noqa: E712
        if admin is None:
            admin = session.exec(select(User)).first()
        admin_id = admin.id if admin else None

        def ensure_league(code: str, name: str, is_world: bool):
            lg = session.exec(select(League).where(League.code == code)).first()
            created = False
            if lg is None:
                lg = League(name=name, code=code, is_world=is_world, created_by=admin_id)
                session.add(lg)
                session.commit()
                session.refresh(lg)
                created = True
            return lg, created

        def add_member_if_absent(league_id: int, user_id: int):
            exists = session.exec(
                select(LeagueMember).where(
                    LeagueMember.league_id == league_id,
                    LeagueMember.user_id == user_id,
                )
            ).first()
            if exists is None:
                session.add(LeagueMember(league_id=league_id, user_id=user_id))

        users = session.exec(select(User)).all()

        world, _ = ensure_league(WORLD_CODE, "World", True)
        for u in users:
            add_member_if_absent(world.id, u.id)

        goal, goal_created = ensure_league(GOAL2026_CODE, "GOAL2026", False)
        if goal_created:
            # One-time backfill of the pre-existing friends into GOAL2026.
            for u in users:
                add_member_if_absent(goal.id, u.id)

        session.commit()


def _ensure_columns():
    """Lightweight, non-destructive migration: add new columns if an older DB
    is missing them (SQLModel's create_all won't alter existing tables)."""
    needed = {"user": {"mascot": "VARCHAR"}}
    with engine.connect() as conn:
        for table, cols in needed.items():
            existing = {r[1] for r in conn.execute(text(f"PRAGMA table_info({table})")).fetchall()}
            for col, coltype in cols.items():
                if col not in existing:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {coltype}"))
        conn.commit()


def get_session():
    with Session(engine) as session:
        yield session
