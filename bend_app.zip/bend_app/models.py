from datetime import datetime
from typing import Optional

from sqlmodel import SQLModel, Field

# NOTE: every datetime in this app is naive UTC. We never store local time.


class User(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True)
    password_hash: str
    display_name: str
    supported_country: Optional[str] = None   # e.g. "Brazil"
    avatar_path: Optional[str] = None
    mascot: Optional[str] = None               # "eagle" | "jaguar" | "moose"
    is_admin: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)


class League(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    code: str = Field(index=True, unique=True)
    is_world: bool = Field(default=False, index=True)
    created_by: Optional[int] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class LeagueMember(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    league_id: int = Field(index=True)
    user_id: int = Field(index=True)
    joined_at: datetime = Field(default_factory=datetime.utcnow)


class Team(SQLModel, table=True):
    # id is the ESPN team id.
    id: int = Field(primary_key=True)
    name: str = Field(index=True)
    elo: float = 1700.0
    logo: Optional[str] = None


class Fixture(SQLModel, table=True):
    # id is the ESPN event id.
    id: int = Field(primary_key=True)
    home_id: int
    away_id: int
    home_name: str
    away_name: str
    kickoff: datetime = Field(index=True)      # naive UTC
    venue: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    stage: Optional[str] = None
    status: str = "NS"                          # NS (scheduled) / LIVE / FT (finished)
    home_score: Optional[int] = None
    away_score: Optional[int] = None
    settled: bool = Field(default=False, index=True)


class Bet(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(index=True)
    fixture_id: int = Field(index=True)
    market: str                                # "1X2" or "SCORELINE"
    selection: str                             # "HOME"/"DRAW"/"AWAY" or "2-1"
    stake: int
    odds: float                                # snapshot at placement
    payout: float                              # potential return = stake * odds
    status: str = "pending"                    # pending / won / lost / void
    profit: Optional[float] = None             # set on settlement
    placed_at: datetime = Field(default_factory=datetime.utcnow)
    settled_at: Optional[datetime] = None
